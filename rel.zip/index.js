export { translate } from './internal/translator.js'
